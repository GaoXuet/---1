package com.util;

public class Constants {
	
	public static final String SESSION_ADMIN_BEANS = "adminBeans";
	public static final int PAGE_SIZE_5 = 5;
	public static final int PAGE_SIZE_1 = 1;

}
