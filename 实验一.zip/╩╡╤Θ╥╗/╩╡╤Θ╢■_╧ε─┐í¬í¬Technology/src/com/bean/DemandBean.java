package com.bean;

public class DemandBean {

	private String WJID;
	private String username;	//用户名
	private String SZDY;
	private int SFSH;	//0表示未通过，1表示通过，缺省取值为0
	private String JGMC;
	private String GLBM;
	private String TXDZ;
	private String DWWZ;
	private String DZYX;
	private String FRDB;
	private String YZBM;
	private String LXR;
	private String GDDH;
	private String YDDH;
	private String CZ;
	private String JGSX;
	private String JGJJ;
	private String JSXQMC;
	private int QSXQNF;
	private int JZXQNF;
	private String ZDKJXQGS;
	private String GJZ;
	private String YJLX;
	private String XKFL1;
	private String XKFL2;
	private String XKFL3;
	private String XQJSSSLY;
	private String QTJSMS;
	private String XQJSYYHY1;
	private String XQJSYYHY2;
	private String XQJSYYHY3;
	private String JSXQHZMS;
	private String HZYXDW;
	private String NTR;
	private String createDate;
	private String V;
	
	
	
	public String getV() {
		return V;
	}
	public void setV(String v) {
		V = v;
	}
	public String getSZDY() {
		return SZDY;
	}
	public void setSZDY(String sZDY) {
		SZDY = sZDY;
	}
	public String getGLBM() {
		return GLBM;
	}
	public void setGLBM(String gLBM) {
		GLBM = gLBM;
	}
	public String getHZYXDW() {
		return HZYXDW;
	}
	public void setHZYXDW(String hZYXDW) {
		HZYXDW = hZYXDW;
	}
	public String getNTR() {
		return NTR;
	}
	public void setNTR(String nTR) {
		NTR = nTR;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}



	public String getWJID() {
		return WJID;
	}
	public void setWJID(String wJID) {
		WJID = wJID;
	}
	public int getSFSH() {
		return SFSH;
	}
	public void setSFSH(int sFSH) {
		SFSH = sFSH;
	}
	public String getJGMC() {
		return JGMC;
	}
	public void setJGMC(String jGMC) {
		JGMC = jGMC;
	}
	public String getTXDZ() {
		return TXDZ;
	}
	public void setTXDZ(String tXDZ) {
		TXDZ = tXDZ;
	}
	public String getDWWZ() {
		return DWWZ;
	}
	public void setDWWZ(String dWWZ) {
		DWWZ = dWWZ;
	}
	public String getDZYX() {
		return DZYX;
	}
	public void setDZYX(String dZYX) {
		DZYX = dZYX;
	}
	public String getFRDB() {
		return FRDB;
	}
	public void setFRDB(String fRDB) {
		FRDB = fRDB;
	}
	public String getYZBM() {
		return YZBM;
	}
	public void setYZBM(String yZBM) {
		YZBM = yZBM;
	}
	public String getLXR() {
		return LXR;
	}
	public void setLXR(String lXR) {
		LXR = lXR;
	}
	public String getGDDH() {
		return GDDH;
	}
	public void setGDDH(String gDDH) {
		GDDH = gDDH;
	}
	public String getYDDH() {
		return YDDH;
	}
	public void setYDDH(String yDDH) {
		YDDH = yDDH;
	}
	public String getCZ() {
		return CZ;
	}
	public void setCZ(String cZ) {
		CZ = cZ;
	}
	public String getJGSX() {
		return JGSX;
	}
	public void setJGSX(String jGSX) {
		JGSX = jGSX;
	}
	public String getJGJJ() {
		return JGJJ;
	}
	public void setJGJJ(String jGJJ) {
		JGJJ = jGJJ;
	}
	public String getJSXQMC() {
		return JSXQMC;
	}
	public void setJSXQMC(String jSXQMC) {
		JSXQMC = jSXQMC;
	}
	public int getQSXQNF() {
		return QSXQNF;
	}
	public void setQSXQNF(int qSXQNF) {
		QSXQNF = qSXQNF;
	}
	public int getJZXQNF() {
		return JZXQNF;
	}
	public void setJZXQNF(int jZXQNF) {
		JZXQNF = jZXQNF;
	}
	public String getZDKJXQGS() {
		return ZDKJXQGS;
	}
	public void setZDKJXQGS(String zDKJXQGS) {
		ZDKJXQGS = zDKJXQGS;
	}
	public String getGJZ() {
		return GJZ;
	}
	public void setGJZ(String gJZ) {
		GJZ = gJZ;
	}
	public String getYJLX() {
		return YJLX;
	}
	public void setYJLX(String yJLX) {
		YJLX = yJLX;
	}
	
	public String getXKFL1() {
		return XKFL1;
	}
	public void setXKFL1(String xKFL1) {
		XKFL1 = xKFL1;
	}
	public String getXKFL2() {
		return XKFL2;
	}
	public void setXKFL2(String xKFL2) {
		XKFL2 = xKFL2;
	}
	public String getXKFL3() {
		return XKFL3;
	}
	public void setXKFL3(String xKFL3) {
		XKFL3 = xKFL3;
	}
	public String getXQJSSSLY() {
		return XQJSSSLY;
	}
	public void setXQJSSSLY(String xQJSSSLY) {
		XQJSSSLY = xQJSSSLY;
	}
	public String getQTJSMS() {
		return QTJSMS;
	}
	public void setQTJSMS(String qTJSMS) {
		QTJSMS = qTJSMS;
	}
	
	public String getXQJSYYHY1() {
		return XQJSYYHY1;
	}
	public void setXQJSYYHY1(String xQJSYYHY1) {
		XQJSYYHY1 = xQJSYYHY1;
	}
	public String getXQJSYYHY2() {
		return XQJSYYHY2;
	}
	public void setXQJSYYHY2(String xQJSYYHY2) {
		XQJSYYHY2 = xQJSYYHY2;
	}
	public String getXQJSYYHY3() {
		return XQJSYYHY3;
	}
	public void setXQJSYYHY3(String xQJSYYHY3) {
		XQJSYYHY3 = xQJSYYHY3;
	}
	public String getJSXQHZMS() {
		return JSXQHZMS;
	}
	public void setJSXQHZMS(String jSXQHZMS) {
		JSXQHZMS = jSXQHZMS;
	}
	
	
}
